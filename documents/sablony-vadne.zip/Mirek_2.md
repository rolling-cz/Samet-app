<!-- fixture: Mirek_2.md -->
# Dokument postavy — kapitola 2

Pevný úvodní odstavec šablony. Text mimo značky se nemění.

## Co se stalo

{BLOK B_Mirek_1_Historie_1}
{BLOK B_Mirek_1_Historie_2}
{BLOK B_Mirek_1_Historie_3}
{BLOK B_Mirek_1_Historie_4}
{BLOK B_Mirek_1_Historie_5}
{BLOK B_Mirek_1_Cyklus_1}
{BLOK B_Mirek_1_Cyklus_3}
{/BLOK}
