<!-- fixture: Marie_4.md -->
# Dokument postavy — kapitola 4

Pevný úvodní odstavec šablony. Text mimo značky se nemění.

Tato kapitola nemá žádné proměnlivé bloky.
