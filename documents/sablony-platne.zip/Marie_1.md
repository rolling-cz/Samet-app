<!-- fixture: Marie_1.md -->
# Dokument postavy — kapitola 1

Pevný úvodní odstavec šablony. Text mimo značky se nemění.

Tato kapitola nemá žádné proměnlivé bloky.
