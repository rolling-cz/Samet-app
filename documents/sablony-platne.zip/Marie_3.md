<!-- fixture: Marie_3.md -->
# Dokument postavy — kapitola 3

Pevný úvodní odstavec šablony. Text mimo značky se nemění.

## Co se stalo

{BLOK B_Marie_2_Historie_1}
