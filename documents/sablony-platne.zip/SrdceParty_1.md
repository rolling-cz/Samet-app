<!-- fixture: SrdceParty_1.md -->
# Dokument skupiny — kapitola 1

Pevný úvodní odstavec šablony. Text mimo značky se nemění.

Tato kapitola nemá žádné proměnlivé bloky.
