<!-- fixture: Antonin_3.md -->
# Dokument postavy — kapitola 3

Pevný úvodní odstavec šablony. Text mimo značky se nemění.

## Co se stalo

{BLOK B_Antonin_2_Auto_1}

{BLOK B_Antonin_2_Stavka_1}
