<!-- fixture: Funkcionari_3.md -->
# Dokument skupiny — kapitola 3

Pevný úvodní odstavec šablony. Text mimo značky se nemění.

## Co se stalo

{BLOK B_Funkcionari_2_Vedeni_1}

{BLOK B_Funkcionari_2_Zapis_1}
