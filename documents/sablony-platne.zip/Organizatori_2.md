<!-- fixture: Organizatori_2.md -->
# Dokument postavy — kapitola 2

Pevný úvodní odstavec šablony. Text mimo značky se nemění.

Tato kapitola nemá žádné proměnlivé bloky.
