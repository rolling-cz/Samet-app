<!-- fixture: Antonin_2.md -->
# Dokument postavy — kapitola 2

Pevný úvodní odstavec šablony. Text mimo značky se nemění.

## Co se stalo

{BLOK B_Antonin_1_Historie_1}

{BLOK B_Antonin_1_Historie_2}

{BLOK B_Antonin_1_Historie_3}

{BLOK B_Antonin_1_Foto_1}
