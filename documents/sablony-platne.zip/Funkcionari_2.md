<!-- fixture: Funkcionari_2.md -->
# Dokument skupiny — kapitola 2

Pevný úvodní odstavec šablony. Text mimo značky se nemění.

## Co se stalo

{BLOK B_Funkcionari_1_Vedeni_1}
