<!-- fixture: SrdceParty_2.md -->
# Dokument skupiny — kapitola 2

Pevný úvodní odstavec šablony. Text mimo značky se nemění.

## Co se stalo

{BLOK B_SrdceParty_1_Clenove_1}
