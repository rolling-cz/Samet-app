<!-- fixture: Mirek_3.md -->
# Dokument postavy — kapitola 3

Pevný úvodní odstavec šablony. Text mimo značky se nemění.

Tato kapitola nemá žádné proměnlivé bloky.
