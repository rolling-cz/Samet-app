<!-- fixture: Marie_2.md -->
# Dokument postavy — kapitola 2

Pevný úvodní odstavec šablony. Text mimo značky se nemění.

## Co se stalo

{BLOK B_Marie_1_Historie_1}
